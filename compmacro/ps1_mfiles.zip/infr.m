function [in, fr] = infr(x)

in=floor(x);
fr=x-in;